/* 
* Color.cpp
*
* Created: 30-04-2020 10:19:32
* Author: valde
*/


#include "Color.h"

// default constructor
Color::Color()
{
} //Color

// default destructor
Color::~Color()
{
} //~Color
